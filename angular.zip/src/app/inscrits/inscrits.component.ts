import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-inscrits',
  templateUrl: './inscrits.component.html',
  styleUrls: ['./inscrits.component.css']
})
export class InscritsComponent implements OnInit {
  inscrits: any[] | undefined; // Tableau pour stocker les inscrits
  classes: string[] | undefined; // Tableau pour stocker les classes disponibles
  selectedClasse: FormControl = new FormControl(''); // Contrôle pour la sélection de la classe

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadInscrits(); // Appel à la méthode pour charger les inscrits
    this.loadClasses(); // Appel à la méthode pour charger les classes disponibles
  }

  // Méthode pour charger les inscrits depuis l'API
  loadInscrits() {
    this.http.get<any[]>('http://localhost:8080/api/inscription').subscribe(data => {
      this.inscrits = data;
    });
  }

  // Méthode pour charger les classes disponibles depuis l'API
  loadClasses() {
    this.http.get<string[]>('http://localhost:8080/api/classe').subscribe(data => {
      this.classes = data;
    });
  }

  // Méthode pour filtrer les inscrits par classe
  filterByClasse() {
    const selectedClasse = this.selectedClasse.value;
    if (selectedClasse) {
      this.http.get<any[]>(`http://localhost:8080/api/inscription/${selectedClasse}`).subscribe(data => {
        this.inscrits = data;
      });
    } else {
      this.loadInscrits(); // Charger tous les inscrits si aucune classe sélectionnée
    }
  }
}
