import 'dart:convert';
import 'package:http/http.dart' as http;

class ClasseService {
  Future<List> getAllClasses() async {
    final url = Uri.parse('http://localhost:8080/api/classe');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      final List classes = data.map((item) => item['libelle']).toList();
      return classes;
    } else {
      throw Exception('Failed to load classes');
    }
  }
}
