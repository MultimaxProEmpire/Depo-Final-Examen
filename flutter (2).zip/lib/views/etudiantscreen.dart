import 'package:flutter/material.dart';
import 'package:ges_etudiants/model/etudiants.dart';

class Etudiantsscreen extends StatelessWidget {
  final List<Etudiants> etudiants;

  const Etudiantsscreen({super.key, required this.etudiants});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Listes Etudiants'),
      ),
      body: ListView.builder(
        itemCount: etudiants.length,
        itemBuilder: (context, index) {
          Etudiants etudiant = etudiants[index];
          return ListTile(
            title: Text('Nom : ${etudiant.nom}'),
            subtitle: Text('email: ${etudiant.email}, classe:${etudiant.classe.libelle}'),
          );
        },
      ),
    );
  }
}
