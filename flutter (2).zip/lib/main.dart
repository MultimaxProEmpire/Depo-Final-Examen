import 'package:flutter/material.dart';
import 'package:ges_etudiants/model/classe.dart';
import 'package:ges_etudiants/model/etudiants.dart';

import 'views/etudiantscreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestion Etudiants',
      theme: ThemeData(
        primarySwatch: Colors.cyan,
      ),
      home: MenuScreen(),
    );
  }
}

final Classe classes = Classe(libelle: 'L3GLRS', niveau: 'L3', filiere: 'GLRS');

class MenuScreen extends StatelessWidget {
  final List<Etudiants> etudiants = [
    Etudiants(
      nom: 'Daouda Thiam',
      tuteur: 'Khalifa Thiam',
      email: 'daoudathiam@gmail.com',
      password: 'password',
      classe: classes,
    ),
    Etudiants(
      nom: 'Saliou Seck',
      tuteur: 'Khadim Seck',
      email: 'khadimseck@gmail.com',
      password: 'password',
      classe: classes,
    ),
    Etudiants(
      nom: 'Ahmet Cissé',
      tuteur: 'Ibou Cissé',
      email: 'Ahmetcisse22@gmail.com',
      password: 'password',
      classe: classes,
    ),
    Etudiants(
      nom: 'Adiarra Kaba',
      tuteur: 'Cherif Kaba',
      email: 'adiarrakaba33@gmail.com',
      password: 'password',
      classe: classes,
    ),
    Etudiants(
      nom: 'Saliou Seck',
      tuteur: 'Khadim Seck',
      email: 'khadimseck@gmail.com',
      password: 'password',
      classe: classes,
    ),
  ];

  MenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(Icons.home),
        title: const Text('Gestion Etudiant'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showSearch(
                context: context,
                delegate: SearchBarDelegate(),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const Spacer(),
          Container(
            width: double.infinity,
            child: TextButton.icon(
              style: TextButton.styleFrom(
                minimumSize: const Size(
                    double.infinity, 50), // Ajuster la taille du bouton ici
              ),
              icon: const Icon(Icons.school),
              label: const Text('Etudiants'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Etudiantsscreen(etudiants: etudiants),
                  ),
                  );
                },
              ),
            ),
          
        ],
      ),
    );
  }
}

class SearchBarDelegate extends SearchDelegate<String> {
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    // Afficher les résultats de la recherche
    return Text('Résultats de la recherche pour : $query');
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // Afficher les suggestions lors de la saisie de recherche
    return Text('Suggestions de recherche pour : $query');
  }
}
