class Classe {
  final String libelle;
  final String niveau;
  final String filiere;

  Classe({required this.libelle, required this.niveau, required this.filiere});
}