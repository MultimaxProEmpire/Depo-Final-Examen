package ism.gesscolaire.RestController;


import ism.gesscolaire.entities.Classe;
import ism.gesscolaire.repositories.ClasseRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/classe")
public class ClasseController {

    @Autowired
    public ClasseRepositories classeRepositories;

    @GetMapping
    public List<String> getAllClasse() {
        return classeRepositories.findAll()
                .stream()
                .map(Classe::getLibelle) // Récupérer uniquement les libellés des classes
                .collect(Collectors.toList());
    }
}
